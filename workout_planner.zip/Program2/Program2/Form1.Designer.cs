﻿namespace Program2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameBox = new System.Windows.Forms.TextBox();
            this.ageBox = new System.Windows.Forms.TextBox();
            this.exercise_type_box = new System.Windows.Forms.ComboBox();
            this.durationBox = new System.Windows.Forms.TextBox();
            this.hydration_cbox = new System.Windows.Forms.GroupBox();
            this.smoke_cbox = new System.Windows.Forms.GroupBox();
            this.log_activity_button = new System.Windows.Forms.Button();
            this.hydration_button_yes = new System.Windows.Forms.RadioButton();
            this.hydration_button_no = new System.Windows.Forms.RadioButton();
            this.smoke_button_yes = new System.Windows.Forms.RadioButton();
            this.smoke_button_no = new System.Windows.Forms.RadioButton();
            this.Namelabel = new System.Windows.Forms.Label();
            this.ageLabel = new System.Windows.Forms.Label();
            this.exercise_type_label = new System.Windows.Forms.Label();
            this.durationLabel = new System.Windows.Forms.Label();
            this.results_cbox = new System.Windows.Forms.GroupBox();
            this.pointsLabel = new System.Windows.Forms.Label();
            this.adjustedLabel = new System.Windows.Forms.Label();
            this.pointsBox = new System.Windows.Forms.TextBox();
            this.adjustedBox = new System.Windows.Forms.TextBox();
            this.hydration_cbox.SuspendLayout();
            this.smoke_cbox.SuspendLayout();
            this.results_cbox.SuspendLayout();
            this.SuspendLayout();
            // 
            // nameBox
            // 
            this.nameBox.Location = new System.Drawing.Point(166, 74);
            this.nameBox.Name = "nameBox";
            this.nameBox.Size = new System.Drawing.Size(100, 20);
            this.nameBox.TabIndex = 0;
            this.nameBox.TextChanged += new System.EventHandler(this.nameBox_TextChanged);
            // 
            // ageBox
            // 
            this.ageBox.Location = new System.Drawing.Point(166, 114);
            this.ageBox.Name = "ageBox";
            this.ageBox.Size = new System.Drawing.Size(100, 20);
            this.ageBox.TabIndex = 1;
            this.ageBox.TextChanged += new System.EventHandler(this.ageBox_TextChanged);
            // 
            // exercise_type_box
            // 
            this.exercise_type_box.FormattingEnabled = true;
            this.exercise_type_box.Items.AddRange(new object[] {
            "Running",
            "Weight Training",
            "Cycling",
            "Yoga",
            "Other"});
            this.exercise_type_box.Location = new System.Drawing.Point(166, 157);
            this.exercise_type_box.Name = "exercise_type_box";
            this.exercise_type_box.Size = new System.Drawing.Size(121, 21);
            this.exercise_type_box.TabIndex = 3;
            this.exercise_type_box.SelectedIndexChanged += new System.EventHandler(this.exercise_type_box_SelectedIndexChanged);
            // 
            // durationBox
            // 
            this.durationBox.Location = new System.Drawing.Point(166, 200);
            this.durationBox.Name = "durationBox";
            this.durationBox.Size = new System.Drawing.Size(100, 20);
            this.durationBox.TabIndex = 4;
            this.durationBox.TextChanged += new System.EventHandler(this.durationBox_TextChanged);
            // 
            // hydration_cbox
            // 
            this.hydration_cbox.Controls.Add(this.hydration_button_no);
            this.hydration_cbox.Controls.Add(this.hydration_button_yes);
            this.hydration_cbox.Location = new System.Drawing.Point(166, 226);
            this.hydration_cbox.Name = "hydration_cbox";
            this.hydration_cbox.Size = new System.Drawing.Size(222, 89);
            this.hydration_cbox.TabIndex = 5;
            this.hydration_cbox.TabStop = false;
            this.hydration_cbox.Text = "Have you hydrated today?";
            this.hydration_cbox.Enter += new System.EventHandler(this.hydration_cbox_Enter);
            // 
            // smoke_cbox
            // 
            this.smoke_cbox.Controls.Add(this.smoke_button_no);
            this.smoke_cbox.Controls.Add(this.smoke_button_yes);
            this.smoke_cbox.Location = new System.Drawing.Point(166, 321);
            this.smoke_cbox.Name = "smoke_cbox";
            this.smoke_cbox.Size = new System.Drawing.Size(237, 93);
            this.smoke_cbox.TabIndex = 6;
            this.smoke_cbox.TabStop = false;
            this.smoke_cbox.Text = "Do you smoke?";
            this.smoke_cbox.Enter += new System.EventHandler(this.smoke_cbox_Enter);
            // 
            // log_activity_button
            // 
            this.log_activity_button.BackColor = System.Drawing.SystemColors.HotTrack;
            this.log_activity_button.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.log_activity_button.Location = new System.Drawing.Point(166, 435);
            this.log_activity_button.Name = "log_activity_button";
            this.log_activity_button.Size = new System.Drawing.Size(75, 23);
            this.log_activity_button.TabIndex = 7;
            this.log_activity_button.Text = "Log Activity";
            this.log_activity_button.UseVisualStyleBackColor = false;
            this.log_activity_button.Click += new System.EventHandler(this.log_activity_button_Click);
            // 
            // hydration_button_yes
            // 
            this.hydration_button_yes.AutoSize = true;
            this.hydration_button_yes.Location = new System.Drawing.Point(6, 66);
            this.hydration_button_yes.Name = "hydration_button_yes";
            this.hydration_button_yes.Size = new System.Drawing.Size(43, 17);
            this.hydration_button_yes.TabIndex = 0;
            this.hydration_button_yes.TabStop = true;
            this.hydration_button_yes.Text = "Yes";
            this.hydration_button_yes.UseVisualStyleBackColor = true;
            this.hydration_button_yes.CheckedChanged += new System.EventHandler(this.hydration_button_yes_CheckedChanged);
            // 
            // hydration_button_no
            // 
            this.hydration_button_no.AutoSize = true;
            this.hydration_button_no.Location = new System.Drawing.Point(131, 66);
            this.hydration_button_no.Name = "hydration_button_no";
            this.hydration_button_no.Size = new System.Drawing.Size(39, 17);
            this.hydration_button_no.TabIndex = 1;
            this.hydration_button_no.TabStop = true;
            this.hydration_button_no.Text = "No";
            this.hydration_button_no.UseVisualStyleBackColor = true;
            this.hydration_button_no.CheckedChanged += new System.EventHandler(this.hydration_button_no_CheckedChanged);
            // 
            // smoke_button_yes
            // 
            this.smoke_button_yes.AutoSize = true;
            this.smoke_button_yes.Location = new System.Drawing.Point(7, 70);
            this.smoke_button_yes.Name = "smoke_button_yes";
            this.smoke_button_yes.Size = new System.Drawing.Size(43, 17);
            this.smoke_button_yes.TabIndex = 0;
            this.smoke_button_yes.TabStop = true;
            this.smoke_button_yes.Text = "Yes";
            this.smoke_button_yes.UseVisualStyleBackColor = true;
            this.smoke_button_yes.CheckedChanged += new System.EventHandler(this.smoke_button_yes_CheckedChanged);
            // 
            // smoke_button_no
            // 
            this.smoke_button_no.AutoSize = true;
            this.smoke_button_no.Location = new System.Drawing.Point(131, 70);
            this.smoke_button_no.Name = "smoke_button_no";
            this.smoke_button_no.Size = new System.Drawing.Size(39, 17);
            this.smoke_button_no.TabIndex = 1;
            this.smoke_button_no.TabStop = true;
            this.smoke_button_no.Text = "No";
            this.smoke_button_no.UseVisualStyleBackColor = true;
            this.smoke_button_no.CheckedChanged += new System.EventHandler(this.smoke_button_no_CheckedChanged);
            // 
            // Namelabel
            // 
            this.Namelabel.AutoSize = true;
            this.Namelabel.Location = new System.Drawing.Point(83, 74);
            this.Namelabel.Name = "Namelabel";
            this.Namelabel.Size = new System.Drawing.Size(38, 13);
            this.Namelabel.TabIndex = 8;
            this.Namelabel.Text = "Name:";
            this.Namelabel.Click += new System.EventHandler(this.label3_Click);
            // 
            // ageLabel
            // 
            this.ageLabel.AutoSize = true;
            this.ageLabel.Location = new System.Drawing.Point(86, 117);
            this.ageLabel.Name = "ageLabel";
            this.ageLabel.Size = new System.Drawing.Size(29, 13);
            this.ageLabel.TabIndex = 9;
            this.ageLabel.Text = "Age:";
            // 
            // exercise_type_label
            // 
            this.exercise_type_label.AutoSize = true;
            this.exercise_type_label.Location = new System.Drawing.Point(83, 160);
            this.exercise_type_label.Name = "exercise_type_label";
            this.exercise_type_label.Size = new System.Drawing.Size(77, 13);
            this.exercise_type_label.TabIndex = 10;
            this.exercise_type_label.Text = "Exercise Type:";
            // 
            // durationLabel
            // 
            this.durationLabel.AutoSize = true;
            this.durationLabel.Location = new System.Drawing.Point(83, 203);
            this.durationLabel.Name = "durationLabel";
            this.durationLabel.Size = new System.Drawing.Size(50, 13);
            this.durationLabel.TabIndex = 11;
            this.durationLabel.Text = "Duration:";
            // 
            // results_cbox
            // 
            this.results_cbox.Controls.Add(this.adjustedBox);
            this.results_cbox.Controls.Add(this.pointsBox);
            this.results_cbox.Controls.Add(this.adjustedLabel);
            this.results_cbox.Controls.Add(this.pointsLabel);
            this.results_cbox.Location = new System.Drawing.Point(135, 503);
            this.results_cbox.Name = "results_cbox";
            this.results_cbox.Size = new System.Drawing.Size(326, 160);
            this.results_cbox.TabIndex = 12;
            this.results_cbox.TabStop = false;
            this.results_cbox.Text = "Your Points:";
            this.results_cbox.Enter += new System.EventHandler(this.results_cbox_Enter);
            // 
            // pointsLabel
            // 
            this.pointsLabel.AutoSize = true;
            this.pointsLabel.Location = new System.Drawing.Point(71, 71);
            this.pointsLabel.Name = "pointsLabel";
            this.pointsLabel.Size = new System.Drawing.Size(39, 13);
            this.pointsLabel.TabIndex = 1;
            this.pointsLabel.Text = "Points:";
            // 
            // adjustedLabel
            // 
            this.adjustedLabel.AutoSize = true;
            this.adjustedLabel.Location = new System.Drawing.Point(71, 100);
            this.adjustedLabel.Name = "adjustedLabel";
            this.adjustedLabel.Size = new System.Drawing.Size(51, 13);
            this.adjustedLabel.TabIndex = 2;
            this.adjustedLabel.Text = "Adjusted:";
            // 
            // pointsBox
            // 
            this.pointsBox.Location = new System.Drawing.Point(177, 64);
            this.pointsBox.Name = "pointsBox";
            this.pointsBox.Size = new System.Drawing.Size(100, 20);
            this.pointsBox.TabIndex = 3;
            this.pointsBox.TextChanged += new System.EventHandler(this.pointsBox_TextChanged);
            // 
            // adjustedBox
            // 
            this.adjustedBox.Location = new System.Drawing.Point(177, 97);
            this.adjustedBox.Name = "adjustedBox";
            this.adjustedBox.Size = new System.Drawing.Size(100, 20);
            this.adjustedBox.TabIndex = 4;
            this.adjustedBox.TextChanged += new System.EventHandler(this.adjustedBox_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(564, 733);
            this.Controls.Add(this.results_cbox);
            this.Controls.Add(this.durationLabel);
            this.Controls.Add(this.exercise_type_label);
            this.Controls.Add(this.ageLabel);
            this.Controls.Add(this.Namelabel);
            this.Controls.Add(this.log_activity_button);
            this.Controls.Add(this.smoke_cbox);
            this.Controls.Add(this.hydration_cbox);
            this.Controls.Add(this.durationBox);
            this.Controls.Add(this.exercise_type_box);
            this.Controls.Add(this.ageBox);
            this.Controls.Add(this.nameBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.hydration_cbox.ResumeLayout(false);
            this.hydration_cbox.PerformLayout();
            this.smoke_cbox.ResumeLayout(false);
            this.smoke_cbox.PerformLayout();
            this.results_cbox.ResumeLayout(false);
            this.results_cbox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox nameBox;
        private System.Windows.Forms.TextBox ageBox;
        private System.Windows.Forms.ComboBox exercise_type_box;
        private System.Windows.Forms.TextBox durationBox;
        private System.Windows.Forms.GroupBox hydration_cbox;
        private System.Windows.Forms.GroupBox smoke_cbox;
        private System.Windows.Forms.Button log_activity_button;
        private System.Windows.Forms.RadioButton hydration_button_no;
        private System.Windows.Forms.RadioButton hydration_button_yes;
        private System.Windows.Forms.RadioButton smoke_button_no;
        private System.Windows.Forms.RadioButton smoke_button_yes;
        private System.Windows.Forms.Label Namelabel;
        private System.Windows.Forms.Label ageLabel;
        private System.Windows.Forms.Label exercise_type_label;
        private System.Windows.Forms.Label durationLabel;
        private System.Windows.Forms.GroupBox results_cbox;
        private System.Windows.Forms.TextBox adjustedBox;
        private System.Windows.Forms.TextBox pointsBox;
        private System.Windows.Forms.Label adjustedLabel;
        private System.Windows.Forms.Label pointsLabel;
    }
}

