﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// Mason Tatafu
// Program 2
// Grading ID: S2407

namespace Program2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void nameBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void ageBox_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void exercise_type_box_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void durationBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void hydration_cbox_Enter(object sender, EventArgs e)
        {

        }

        private void hydration_button_yes_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void hydration_button_no_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void smoke_cbox_Enter(object sender, EventArgs e)
        {

        }

        private void smoke_button_yes_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void smoke_button_no_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void log_activity_button_Click(object sender, EventArgs e)
        {
            //declarations of variables
            string user_name = nameBox.Text;
            string age = ageBox.Text;

            //tryParse for age
            if (int.TryParse(age, out int user_age))
            {

            }
            else
            {
                MessageBox.Show("Invalid input for age");
            }

            // checking if an exercise was selected
            string selected_exercise = exercise_type_box.Text;
            if (exercise_type_box.SelectedIndex==-1)
            { 
                MessageBox.Show("You did not select an exercise type.");
            }
            
            //tryParse for duration
            string user_duration = durationBox.Text;
            if (int.TryParse(user_duration, out int exercise_duration))
            {

            }
            else
            {
                MessageBox.Show("Invalid value for exercise duration.");
            }

            // checking if at least one button was checked
            if(!hydration_button_yes.Checked && !hydration_button_no.Checked)
            {
                MessageBox.Show("You did not indicate your hydration.");
            }

            //checking if at least one button was checked
            if(!smoke_button_yes.Checked && !smoke_button_no.Checked)
            {
                MessageBox.Show("You did not indicate your smoking habit");
            }

            //declarations
            double user_points;
            double user_points_adjusted;


            // the following few blocks of code applies the points rate calculation
            // it then checks if they were hydrated or smoking for multiplication situations
            // assigns one var to value points, assigns another to value adjusted
            if(selected_exercise == "Running")
            {
                user_points = 10 * exercise_duration;
                pointsBox.Text = user_points.ToString();
                if(hydration_button_yes.Checked)
                {
                    user_points_adjusted = user_points * 1.1;
                    adjustedBox.Text = user_points_adjusted.ToString();
                }
                if(smoke_button_yes.Checked)
                {
                    user_points_adjusted = user_points * 0.5;
                    adjustedBox.Text = user_points_adjusted.ToString();
                }
                
            }
            if(selected_exercise == "Weight Training")
            {
                user_points = 20 * exercise_duration;
                pointsBox.Text = user_points.ToString();
                if (hydration_button_yes.Checked)
                {
                    user_points_adjusted = user_points * 1.1;
                    adjustedBox.Text = user_points_adjusted.ToString();
                }
                if (smoke_button_yes.Checked)
                {
                    user_points_adjusted = user_points * 0.5;
                    adjustedBox.Text = user_points_adjusted.ToString();
                }
            }
            if (selected_exercise == "Cycling")
            {
                user_points = 5 * exercise_duration;
                pointsBox.Text = user_points.ToString();
                if (hydration_button_yes.Checked)
                {
                    user_points_adjusted = user_points * 1.1;
                    adjustedBox.Text = user_points_adjusted.ToString();
                }
                if (smoke_button_yes.Checked)
                {
                    user_points_adjusted = user_points * 0.5;
                    adjustedBox.Text = user_points_adjusted.ToString();
                }
            }
            if(selected_exercise == "Yoga")
            {
                user_points = 2 * exercise_duration;
                pointsBox.Text = user_points.ToString();
                if (hydration_button_yes.Checked)
                {
                    user_points_adjusted = user_points * 1.1;
                    adjustedBox.Text = user_points_adjusted.ToString();
                }
                if (smoke_button_yes.Checked)
                {
                    user_points_adjusted = user_points * 0.5;
                    adjustedBox.Text = user_points_adjusted.ToString();
                }
            }
            if(selected_exercise == "Other")
            {
                user_points = 5 * exercise_duration;
                pointsBox.Text = user_points.ToString();
                if (hydration_button_yes.Checked)
                {
                    user_points_adjusted = user_points * 1.1;
                    adjustedBox.Text = user_points_adjusted.ToString();
                }
                if (smoke_button_yes.Checked)
                {
                    user_points_adjusted = user_points * 0.5;
                    adjustedBox.Text = user_points_adjusted.ToString();
                }

            }


        }

        private void results_cbox_Enter(object sender, EventArgs e)
        {

        }

        private void pointsBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void adjustedBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
